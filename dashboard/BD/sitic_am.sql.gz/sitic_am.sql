-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 06-04-2023 a las 12:10:37
-- Versión del servidor: 5.7.41
-- Versión de PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sitic_am`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `accion` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `bitacora`
--

INSERT INTO `bitacora` (`id`, `usuario`, `accion`, `fecha`) VALUES
(1, 'Alan', 'Inició Sesión', '2023-03-27 22:23:16'),
(2, 'Alan', 'Registró un Auto', '2023-03-27 23:07:07'),
(3, 'Alan', 'Modificó una Marca', '2023-03-27 23:07:37'),
(4, 'Alan', 'Modificó una Marca', '2023-03-27 23:08:04'),
(5, 'Alan', 'Inició Sesión', '2023-03-30 00:02:00'),
(6, 'Alan', 'Eliminó una Marca', '2023-03-30 00:02:36'),
(7, 'Alan', 'Eliminó una Marca', '2023-03-30 00:02:39'),
(8, 'Alan', 'Eliminó una Marca', '2023-03-30 00:02:41'),
(9, 'Alan', 'Eliminó una Marca', '2023-03-30 00:02:44'),
(10, 'Alan', 'Eliminó una Marca', '2023-03-30 00:02:47'),
(11, 'Alan', 'Modificó una Marca', '2023-03-30 00:03:07'),
(12, 'Alan', 'Modificó una Marca', '2023-03-30 00:03:50'),
(13, 'Alan', 'Inició Sesión', '2023-03-30 00:15:03'),
(14, 'Alan', 'Registró un Usuario', '2023-03-30 01:28:28'),
(15, 'Alan', 'Inició Sesión', '2023-03-30 03:41:15'),
(16, 'Alan', 'Registró un Auto', '2023-03-30 04:23:40'),
(17, 'Alan', 'Modificó una Marca', '2023-03-30 04:25:11'),
(18, 'Alan', 'Inició Sesión', '2023-04-03 15:28:18'),
(19, 'alan@gnesys.com', 'Inició Sesión', '2023-04-03 16:01:30'),
(20, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 17:46:04'),
(21, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 17:55:12'),
(22, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 17:55:52'),
(23, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 17:56:11'),
(24, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 18:05:56'),
(25, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 18:09:34'),
(26, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 18:14:50'),
(27, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 18:15:25'),
(28, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 18:16:07'),
(29, 'alan@gnesys.com', 'Inició Sesión', '2023-04-03 19:17:25'),
(30, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 19:18:12'),
(31, 'alan@gnesys.com', 'Modificó una Marca', '2023-04-03 19:22:01'),
(32, 'alan@gnesys.com', 'Modificó una Marca', '2023-04-03 19:22:16'),
(33, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 19:32:16'),
(34, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 19:55:49'),
(35, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 19:55:55'),
(36, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 19:56:04'),
(37, 'alan@gnesys.com', 'Eliminó una Marca', '2023-04-03 19:56:09'),
(38, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 20:00:47'),
(39, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 20:01:26'),
(40, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 20:02:15'),
(41, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 20:02:18'),
(42, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 20:02:23'),
(43, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 20:03:58'),
(44, 'alan@gnesys.com', 'Inició Sesión', '2023-04-03 21:40:21'),
(45, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 21:40:38'),
(46, 'alan@gnesys.com', 'Eliminó un Auto', '2023-04-03 21:40:41'),
(47, 'alan@gnesys.com', 'Registró un Auto', '2023-04-03 21:54:29'),
(74, 'Alan', 'Eliminó un Auto', '2023-04-04 16:08:37'),
(73, 'Alan', 'Registró un Auto', '2023-04-04 16:07:39'),
(71, 'Alan', 'Eliminó un Auto', '2023-04-04 15:50:28'),
(72, 'Alan', 'Inició Sesión', '2023-04-04 16:03:48'),
(67, 'Alan', 'Inició Sesión', '2023-04-04 14:07:34'),
(68, 'Alan', 'Inició Sesión', '2023-04-04 15:39:01'),
(69, 'Alan', 'Registró un Auto', '2023-04-04 15:46:18'),
(70, 'Alan', 'Registró un Auto', '2023-04-04 15:46:44'),
(78, 'Alan', 'Registró un Usuario', '2023-04-05 02:50:20'),
(77, 'Alan', 'Inició Sesión', '2023-04-05 02:47:59'),
(76, 'Alan', 'Inició Sesión', '2023-04-04 19:59:55'),
(75, 'Alan', 'Inició Sesión', '2023-04-04 18:55:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `ID` int(11) NOT NULL,
  `CLASE` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `TIPO` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TAG` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `DESCRIPCION` text CHARACTER SET utf8
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`ID`, `CLASE`, `TIPO`, `TAG`, `DESCRIPCION`) VALUES
(1, 'Clase 1', 'PRODUCTOS', 'Productos químicos', 'Productos químicos en general'),
(2, 'Clase 2', 'PRODUCTOS', 'Pintura', 'Colores, barnices y lacas'),
(3, 'Clase 3', 'PRODUCTOS', 'Limpiadores', 'Preparaciones para blanquear, limpiar, pulir, desengrasar y raspar, jabones, perfumería, cosméticos, lociones para el cabello, dentífricos.'),
(4, 'Clase 4', 'PRODUCTOS', 'Aceites y lubricantes', 'Aceites, grasas industriales y lubricantes'),
(5, 'Clase 5', 'PRODUCTOS', 'Farmacéuticos', 'Productos farmacéuticos, veterinarios, funguicidas y herbicidas.'),
(6, 'Clase 6', 'PRODUCTOS', 'Metales', 'Metales comunes y sus aleaciones, materiales de construcción metálicos'),
(7, 'Clase 7', 'PRODUCTOS', 'Máquinas y motores', 'Máquinas y máquinas de herramientas; motores  (excepto para vehículos terrestres) '),
(8, 'Clase 8', 'PRODUCTOS', 'Herramientas e instrumentos', 'Herramientas e instrumentos impulsados manualmente; cuchillería, tenedores y cucharas, armas blancas'),
(9, 'Clase 9', 'PRODUCTOS', 'Instrumentos tecnológicos', 'Aparatos e instrumentos científicos, náuticos, geodésicos, eléctricos, fotográficos, cinematográficos, ópticos, de pesar, de medir, de señalización, de control, de socorro, de enseñanza, aparatos para el registro, transmisión, reproducción de sonido e imá'),
(10, 'Clase 10', 'PRODUCTOS', 'Instrumentos médicos', 'Aparatos e instrumentos quirúrgicos, médicos, dentales y ortopédicos'),
(11, 'Clase 11', 'PRODUCTOS', 'Alumbrado y línea blanca', 'Aparatos de alumbrado, de calefacción, de producción de vapor, de cocción, de refrigeración, de secado, de ventilación, de distribución de agua, e instalaciones sanitarias.'),
(12, 'Clase 12', 'PRODUCTOS', 'Vehículos motores', 'Vehículos, aparatos de locomoción terrestre, aérea o marítima.'),
(13, 'Clase 13', 'PRODUCTOS', 'Armas y fuegos artificiales', 'Armas de fuego, municiones, y proyectiles, explosivos, fuegos artificiales.'),
(14, 'Clase 14', 'PRODUCTOS', 'Metales preciosos', 'Metales preciosos y sus aleaciones y objetos de estas materias, o de chapado no comprendidos en otras clases, joyería, bisutería, y piedras preciosas, relojería e instrumentos cronométricos.'),
(15, 'Clase 15', 'PRODUCTOS', 'Instrumentos de música.', 'Instrumentos de música.'),
(16, 'Clase 16', 'PRODUCTOS', 'Impresiones y publicaciones ', 'Impresiones y publicaciones '),
(17, 'Clase 17', 'PRODUCTOS', 'Materiales plásticos y varios', 'Caucho, goma, mica y productos de estas materias no comprendidos en otras clases; productos en materias plásticas semielaboradas; tubos flexibles no metálicos.'),
(18, 'Clase 18', 'PRODUCTOS', 'Cuero e imitación', 'Cuero e imitaciones de cuero, productos de estas materias no comprendidos en otras clases, pieles de animales, baúles y maletas, paraguas, sombrillas  y bastones. '),
(19, 'Clase 19', 'PRODUCTOS', 'Materias de construcción', 'Materiales de construcción no metálicos'),
(20, 'Clase 20', 'PRODUCTOS', 'Muebles y decoración', 'Muebles, espejos, marcos, productos no comprendidos en otras clases de madera, corcho, caña, junco, mimbre, cuerno, hueso, marfil, ballena, concha, ámbar, nácar, espuma de mar, sucedáneos, de todas estas materias y materias plásticas.'),
(21, 'Clase 21', 'PRODUCTOS', 'Utencilios de cocina', 'Utensilios y recipientes para el menaje o la cocina, cristalería, porcelana y loza, no comprendidas en otras clases. '),
(22, 'Clase 22', 'PRODUCTOS', 'Cuardas y toldos', 'Cuerda, bramantes, redes, tiendas de campaña, toldos, velas'),
(23, 'Clase 23', 'PRODUCTOS', 'Hilos', 'Hilos para uso textil.'),
(24, 'Clase 24', 'PRODUCTOS', 'Textiles', 'Tejidos y productos textiles no comprendidos en otras clases, ropa de cama y de mesa.'),
(25, 'Clase 25', 'PRODUCTOS', 'Vestido y calzado', 'Vestidos, calzado, sombrerería.'),
(26, 'Clase 26', 'PRODUCTOS', 'Bordados y botones', 'Puntillas y bordados, cintas y lazos, botones'),
(27, 'Clase 27', 'PRODUCTOS', 'Tapicería', 'Alfombras, felpudos, esteras, linóleum y otros revestimientos de suelos, tapicerías, murales que no sean de materias textiles.'),
(28, 'Clase 28', 'PRODUCTOS', 'Deportes', 'Juegos, juguetes, artículos de gimnasia y deporte no comprendidos en otras clases'),
(29, 'Clase 29', 'PRODUCTOS', 'Carne, frutas y legumbres', 'Carne, pescado, aves de caza, y extractos de carne, frutas y legumbres en conserva secas y  cocidas, jaleas, mermeladas, huevos, leche y productos lácteos, aceites  y grasas comestibles, salsas para ensaladas conservas.'),
(30, 'Clase 30', 'PRODUCTOS', 'Café y cereales', 'Café, té, cacao, azúcar, arroz, tapioca, sagú, sucedáneos del café, harinas y preparaciones hechas de cereales, pan, pastelería y confitería, helados comestibles, miel, jarabe de melaza, levaduras, polvos para esponjar, sal, mostaza, vinagre, salsas (con '),
(31, 'Clase 31', 'PRODUCTOS', 'Agricultura', 'Productos agrícolas, hortícolas, forestales y granos no comprendidos en otras clases, animales vivos, frutas y legumbres frescas, semillas, plantas y flores naturales, alimentos para animales.'),
(32, 'Clase 32', 'PRODUCTOS', 'Bebidas', 'Cerveza, aguas minerales y gaseosa y otras bebidas, no alcohólicas, bebidas y zumos (jugos) de frutas, jarabes y otras preparaciones para hacer bebidas.'),
(33, 'Clase 33', 'PRODUCTOS', 'Bebidas alcohólicas', 'Bebidas alcohólicas  (con excepción de cervezas).'),
(34, 'Clase 34', 'PRODUCTOS', 'Tabaco', 'Tabaco, artículos para fumadores, cerillas (cerillos) fósforos.'),
(35, 'Clase 35', 'SERVICIOS', 'Publicidad', 'Publicidad y negocios.'),
(36, 'Clase 36', 'SERVICIOS', 'Seguros y fianzas.', 'Seguros y fianzas.'),
(37, 'Clase 37', 'SERVICIOS', 'Construcción', 'Construcción y reparaciones.'),
(38, 'Clase 38', 'SERVICIOS', 'Comunicaciones.', 'Comunicaciones.'),
(39, 'Clase 39', 'SERVICIOS', 'Transporte', 'Transporte y depósito.'),
(40, 'Clase 40', 'SERVICIOS', 'Maquila', 'Transformación de materiales y maquila.'),
(41, 'Clase 41', 'SERVICIOS', 'Educación', 'Educación y esparcimiento.'),
(42, 'Clase 42', 'SERVICIOS', 'Tecnología', 'Investigación y servicios tecnológicos, análisis y desarrollo de equipo y software.'),
(43, 'Clase 43', 'SERVICIOS', 'Alimentos', 'Restaurantes, bares  y hoteles.'),
(44, 'Clase 44', 'SERVICIOS', 'Salud', 'Servicios médicos, veterinarios, servicios de belleza, y servicios de agricultura.'),
(45, 'Clase 45', 'SERVICIOS', 'Legal', 'Servicios legales y de seguridad.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color`
--

CREATE TABLE `color` (
  `id` int(11) NOT NULL,
  `color` varchar(50) NOT NULL,
  `tipocolor` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `color`
--

INSERT INTO `color` (`id`, `color`, `tipocolor`) VALUES
(1, 'Blanco', 'Ext'),
(2, 'Negro', 'Ext'),
(3, 'Plata', 'Ext'),
(4, 'Azul', 'Ext'),
(5, 'Gris', 'Ext'),
(6, 'Rojo', 'Ext'),
(7, 'Negro', 'Int'),
(8, 'Blanco', 'Int'),
(9, 'Gris', 'Int'),
(10, 'Beige', 'Int');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `combustible`
--

CREATE TABLE `combustible` (
  `id` int(11) NOT NULL,
  `combustible` varchar(50) NOT NULL,
  `nota` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `combustible`
--

INSERT INTO `combustible` (`id`, `combustible`, `nota`) VALUES
(1, 'Gasolina', ''),
(2, 'Eléctrico', ''),
(3, 'Híbrido', ''),
(4, 'Híbrido Enchufable', ''),
(5, 'Diesel', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL,
  `car_code` varchar(100) NOT NULL,
  `id_asociado` int(11) NOT NULL,
  `condicion` varchar(20) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `marca` varchar(30) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `version` varchar(50) NOT NULL,
  `ano` varchar(4) NOT NULL,
  `transmision` varchar(30) NOT NULL,
  `combustible` varchar(30) NOT NULL,
  `kilometraje` int(30) NOT NULL,
  `color_int` varchar(15) NOT NULL,
  `color_ext` varchar(15) NOT NULL,
  `tam_motor` varchar(15) NOT NULL,
  `cilindros` varchar(5) NOT NULL,
  `conduccion` varchar(30) NOT NULL,
  `status` tinyint(2) DEFAULT '0' COMMENT '0=Inactive,1=Active',
  `precio` double NOT NULL,
  `note` text NOT NULL,
  `observaciones` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IMG` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `id_usuario` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id`, `car_code`, `id_asociado`, `condicion`, `tipo`, `marca`, `modelo`, `version`, `ano`, `transmision`, `combustible`, `kilometraje`, `color_int`, `color_ext`, `tam_motor`, `cilindros`, `conduccion`, `status`, `precio`, `note`, `observaciones`, `created_at`, `IMG`, `id_usuario`) VALUES
(1, 'AM0077', 13, 'usado', 'SUV', 'Toyota', 'RAV4', 'LS', '2015', 'automatica', 'Gasolina', 99999, 'Gris', 'Plata', '2.4', '3', '', 0, 150000, 'Nota', 'Obs', '2023-04-04 00:06:01', '../images/inventario/AM0079-60974.jpg|../images/inventario/AM0079-65595.jpg|../images/inventario/AM0079-79371.jpg|../images/inventario/AM0079-8500.jpg', '1'),
(10, 'AM0079', 13, 'usado', 'SUV', 'Honda', 'HRV', 'Touring Cvt', '2021', 'automatico', 'Gasolina', 36, 'Blanco', 'Negro', ' 1.8L', '4', '', 0, 459000, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.\r\nPara darte una mejor atención comunícate a nuestros teléfonos: 55-4837-1194, 56-1987-0315 y pregunta por uno de nuestros asesores y vivas tu mejor experiencia en línea.\r\nVisita nuestras instalaciones en: Calle: Santander #69, Colonia: Insurgentes Mixcoac, Benito Juárez, C.P. 03920, CDMX\r\n\r\n¡¡¡Nuestros asesores estarán disponibles para atenderte!!!', '', '2023-04-04 04:01:03', '../images/inventario/AM0079-60974.jpg|../images/inventario/AM0079-65595.jpg|../images/inventario/AM0079-79371.jpg|../images/inventario/AM0079-8500.jpg', '1'),
(11, 'AM0088', 13, 'nuevo', 'Hatchback', 'Chevrolet', 'asd', 'XLS', '2017', 'automatico', 'Electrico', 75000, 'Negro', 'Negro', '2.0', '3', '', 0, 459000, 'asd', 'asd', '2023-04-04 04:01:08', '../images/inventario/AM0088-93216.jpg', '1'),
(12, 'AM0099', 13, 'usado', 'SUV', 'Mazda', 'Toyo', 'asd', '2018', 'automatico', 'Electrico', 91167, 'Gris', 'Negro', '2', '4', '', 0, 490000, 'asd', 'asd', '2023-04-04 00:00:12', '../images/inventario/AM0099-66983.jpg', '1'),
(18, 'AM00523', 14, 'usado', 'SUV', 'Hyundai ', 'Santa Fe ', 'Limited Tech', '2018', 'automatico', 'gasolina', 95, 'Negro', 'Azul', ' 3.4L', '4', '', 0, 478000, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.', '', '2023-04-04 06:50:43', '../images/inventario/AM00523-93235.jpg', '1'),
(19, 'AM00514', 14, 'usado', 'SUV', 'Chevrolet ', 'Tracker ', 'Premier Turbo', '2021', 'automatico', 'gasolina', 28000, 'Negro', 'Azul', ' 1.2L', '4', '', 0, 407800, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.\r\nPara darte una mejor atención comunícate a nuestros teléfonos: 55-4837-1194, 56-1987-0315 y pregunta por uno de nuestros asesores y vivas tu mejor experiencia en línea.\r\nVisita nuestras instalaciones en: Calle: Santander #69, Colonia: Insurgentes Mixcoac, Benito Juárez, C.P. 03920, CDMX\r\n\r\n¡¡¡Nuestros asesores estarán disponibles para atenderte!!!', '', '2023-04-04 06:54:29', '../images/inventario/AM00514-91716.jpg', '1'),
(20, 'AM00516', 14, 'nuevo', 'Sedan', 'Tesla ', 'Model 3 ', 'Estándar Plus', '2020', 'automatico', 'Eléctrico', 207000, 'Negro', 'Blanco', '3', '2', '', 0, 670000, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.\r\nPara darte una mejor atención comunícate a nuestros teléfonos: 55-4837-1194, 56-1987-0315 y pregunta por uno de nuestros asesores y vivas tu mejor experiencia en línea.\r\nVisita nuestras instalaciones en: Calle: Santander #69, Colonia: Insurgentes Mixcoac, Benito Juárez, C.P. 03920, CDMX\r\n\r\n¡¡¡Nuestros asesores estarán disponibles para atenderte!!!', 'Testa', '2023-04-04 06:54:54', '../images/inventario/AM00516-29524.jpg|../images/inventario/AM00516-62021.jpg|../images/inventario/AM00516-58052.jpg|../images/inventario/AM00516-24768.jpg|../images/inventario/AM00516-58188.jpg|../images/inventario/AM00516-52318.jpg|../images/inventario/AM00516-23983.jpg|../images/inventario/AM00516-92220.jpg|../images/inventario/AM00516-71051.jpg', '1'),
(21, 'AM00523', 14, 'usado', 'SUV', 'Hyundai ', 'Santa Fe ', 'Limited Tech', '2018', 'automatico', 'Gasolina', 95000, 'Negro', 'Azul', ' 3.4L', '4', '', 0, 478000, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.', '', '2023-04-04 06:55:15', '../images/inventario/AM00523-93235.jpg', '1'),
(22, 'AM00001', 14, 'nuevo', 'Hatchback', 'Arra', 'Arra 3', 'EX', '2023', 'automatico', 'electrico', 0, 'Negro', 'Blanco', '3', '4', '', 0, 890000, 'Nuevo', '', '2023-04-04 09:44:08', '../images/inventario/AM00001-42421.jpg', '1'),
(24, 'AM00531', 14, 'usado', 'Sedan', 'Volkwagen ', 'Automovil', 'Tipo Sedan Clásico', '1985', 'manual', 'Gasolina', 55000, 'Negro', 'Plata', '1.8L', '4', '', 0, 190000, '¡¡¡ Somos AUTOMAYOREO!!!\r\n\r\nLa empresa líder de compra y venta de autos seminuevos. Ofrecemos confianza y seguridad en todas nuestras opciones.\r\nContamos con financiamiento automotriz y podrás contactarnos para hacerte un perfilamiento y ofrecerte la mejor opción para tu crédito.\r\nTe asesoramos durante todo tu proceso.\r\nTodos nuestros autos cuentan con 90 días de garantía.\r\nPara darte una mejor atención comunícate a nuestros teléfonos: 55-4837-1194, 56-1987-0315 y pregunta por uno de nuestros asesores y vivas tu mejor experiencia en línea.\r\nVisita nuestras instalaciones en: Calle: Santander #69, Colonia: Insurgentes Mixcoac, Benito Juárez, C.P. 03920, CDMX\r\n\r\n¡¡¡Nuestros asesores estarán disponibles para atenderte!!!', '', '2023-04-04 15:46:44', '../images/inventario/AM00531-50848.jpg|../images/inventario/AM00531-60884.jpg', '1'),
(25, 'AM0111', 14, 'usado', 'Sedan', 'Toyota ', 'Rav4', 'XLS', '2019', 'manual', 'electrico', 91167, 'Negro', 'Plata', '2.4', '4', '', 0, 490000, 'dwfedf', '', '2023-04-04 16:07:39', '../images/inventario/AM0111-86526.jpg|../images/inventario/AM0111-5108.jpg', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `price` int(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `name`, `description`, `price`, `category_id`, `created`, `modified`) VALUES
(1, 'LG P880 4X HD', 'My first awesome phone!', 336, 3, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(2, 'Google Nexus 4', 'The most awesome phone of 2013!', 299, 2, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(3, 'Samsung Galaxy S4', 'How about no?', 600, 3, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(6, 'Bench Shirt', 'The best shirt!', 29, 1, '2014-06-01 01:12:26', '2014-05-31 07:42:21'),
(7, 'Lenovo Laptop', 'My business partner.', 399, 2, '2014-06-01 01:13:45', '2014-05-31 07:43:39'),
(8, 'Samsung Galaxy Tab 10.1', 'Good tablet.', 259, 2, '2014-06-01 01:14:13', '2014-05-31 07:44:08'),
(9, 'Spalding Watch', 'My sports watch.', 199, 1, '2014-06-01 01:18:36', '2014-05-31 07:48:31'),
(10, 'Sony Smart Watch', 'The coolest smart watch!', 300, 2, '2014-06-06 17:10:01', '2014-06-05 23:39:51'),
(11, 'Huawei Y300', 'For testing purposes.', 100, 2, '2014-06-06 17:11:04', '2014-06-05 23:40:54'),
(12, 'Abercrombie Lake Arnold Shirt', 'Perfect as gift!', 60, 1, '2014-06-06 17:12:21', '2014-06-05 23:42:11'),
(13, 'Abercrombie Allen Brook Shirt', 'Cool red shirt!', 70, 1, '2014-06-06 17:12:59', '2014-06-05 23:42:49'),
(26, 'Another product', 'Awesome product!', 555, 2, '2014-11-22 19:07:34', '2014-11-22 03:37:34'),
(28, 'Wallet', 'You can absolutely use this one!', 799, 6, '2014-12-04 21:12:03', '2014-12-04 05:42:03'),
(31, 'Amanda Waller Shirt', 'New awesome shirt!', 333, 1, '2014-12-13 00:52:54', '2014-12-12 09:22:54'),
(42, 'Nike Shoes for Men', 'Nike Shoes', 12999, 3, '2015-12-12 06:47:08', '2015-12-12 13:17:08'),
(48, 'Bristol Shoes', 'Awesome shoes.', 999, 5, '2016-01-08 06:36:37', '2016-01-08 13:06:37'),
(60, 'Rolex Watch', 'Luxury watch.', 25000, 1, '2016-01-11 15:46:02', '2016-01-11 22:16:02'),
(1, 'LG P880 4X HD', 'My first awesome phone!', 336, 3, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(2, 'Google Nexus 4', 'The most awesome phone of 2013!', 299, 2, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(3, 'Samsung Galaxy S4', 'How about no?', 600, 3, '2014-06-01 01:12:26', '2014-05-31 22:42:26'),
(6, 'Bench Shirt', 'The best shirt!', 29, 1, '2014-06-01 01:12:26', '2014-05-31 07:42:21'),
(7, 'Lenovo Laptop', 'My business partner.', 399, 2, '2014-06-01 01:13:45', '2014-05-31 07:43:39'),
(8, 'Samsung Galaxy Tab 10.1', 'Good tablet.', 259, 2, '2014-06-01 01:14:13', '2014-05-31 07:44:08'),
(9, 'Spalding Watch', 'My sports watch.', 199, 1, '2014-06-01 01:18:36', '2014-05-31 07:48:31'),
(10, 'Sony Smart Watch', 'The coolest smart watch!', 300, 2, '2014-06-06 17:10:01', '2014-06-05 23:39:51'),
(11, 'Huawei Y300', 'For testing purposes.', 100, 2, '2014-06-06 17:11:04', '2014-06-05 23:40:54'),
(12, 'Abercrombie Lake Arnold Shirt', 'Perfect as gift!', 60, 1, '2014-06-06 17:12:21', '2014-06-05 23:42:11'),
(13, 'Abercrombie Allen Brook Shirt', 'Cool red shirt!', 70, 1, '2014-06-06 17:12:59', '2014-06-05 23:42:49'),
(26, 'Another product', 'Awesome product!', 555, 2, '2014-11-22 19:07:34', '2014-11-22 03:37:34'),
(28, 'Wallet', 'You can absolutely use this one!', 799, 6, '2014-12-04 21:12:03', '2014-12-04 05:42:03'),
(31, 'Amanda Waller Shirt', 'New awesome shirt!', 333, 1, '2014-12-13 00:52:54', '2014-12-12 09:22:54'),
(42, 'Nike Shoes for Men', 'Nike Shoes', 12999, 3, '2015-12-12 06:47:08', '2015-12-12 13:17:08'),
(48, 'Bristol Shoes', 'Awesome shoes.', 999, 5, '2016-01-08 06:36:37', '2016-01-08 13:06:37'),
(60, 'Rolex Watch', 'Luxury watch.', 25000, 1, '2016-01-11 15:46:02', '2016-01-11 22:16:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `ID` int(11) NOT NULL,
  `DENOM` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `CLASE` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `TITULAR` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `NO_REG` int(255) NOT NULL,
  `NO_SOL` int(255) NOT NULL,
  `ULTIMA_CERT_NOTARIAL` date NOT NULL,
  `VIGENCIA` date NOT NULL,
  `PAIS_ORI` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `C_LINK` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `C_TEL` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `C_FAX` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `C_EMAIL` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `PROD_SERV` text COLLATE utf8_spanish_ci NOT NULL,
  `AUTORIZADOS` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `URL_FUENTE` text COLLATE utf8_spanish_ci NOT NULL,
  `OBS` text COLLATE utf8_spanish_ci NOT NULL,
  `IMG` text COLLATE utf8_spanish_ci NOT NULL,
  `DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ID_USUARIO` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`ID`, `DENOM`, `CLASE`, `TITULAR`, `NO_REG`, `NO_SOL`, `ULTIMA_CERT_NOTARIAL`, `VIGENCIA`, `PAIS_ORI`, `C_LINK`, `C_TEL`, `C_FAX`, `C_EMAIL`, `PROD_SERV`, `AUTORIZADOS`, `URL_FUENTE`, `OBS`, `IMG`, `DATE`, `ID_USUARIO`) VALUES
(51, 'asd', '1', 'ads', 0, 0, '0000-00-00', '2023-03-30', 'ds', '', '213', '312', 'ti@automayoreo.com', 'asd', 'asd', '', 'ad', '../images/inventario/asd-6487.jpg', '2023-04-03 19:22:16', 1),
(50, 'Prueba', '5', 'asd', 123123, 0, '0000-00-00', '2023-03-28', 'dasd', '', '123123', '232132', 'ti@automayoreo.com', 'dasdasds', 'asd', '', 'sadasdasd', '../images/marcas/Prueba-64662.jpg|../images/marcas/Prueba-72960.jpg|../images/marcas/Prueba-41484.jpg|../images/marcas/Prueba-80582.jpg|../images/marcas/Prueba-98918.jpg|../images/marcas/Prueba-69179.jpg|../images/marcas/Prueba-68684.jpg', '2023-03-30 00:03:50', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas_res`
--

CREATE TABLE `marcas_res` (
  `id` int(11) NOT NULL,
  `marca` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `categoria` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `marcas_res`
--

INSERT INTO `marcas_res` (`id`, `marca`, `categoria`, `descripcion`) VALUES
(3, 'Toyota', 'Automotríz', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(7, 'Audi', 'Automotríz', 'Audi');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo`
--

CREATE TABLE `tipo` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nota` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`id`, `tipo`, `nota`) VALUES
(1, 'Sedan', ''),
(2, 'SUV', ''),
(3, 'Hatchback', ''),
(4, 'Pickup', ''),
(5, 'VAN', ''),
(6, 'Moto', ''),
(7, 'Coupe', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_email`, `user_status`) VALUES
(1, 'alangeovs', 'alangeovs@gmail.com', 1),
(2, 'juan', 'juanvalencia@gmail.com', 0),
(3, 'John', 'johnqwe@gmail.com', 1),
(4, 'Pedro', 'pedrorrr@gmail.com', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` text COLLATE utf8_spanish_ci NOT NULL,
  `confirmPass` text COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `correo`, `password`, `confirmPass`, `tipo`, `telefono`, `direccion`) VALUES
(1, 'Alan', 'alan@gnesys.com', 'alan3001', '8059218679186d36e8a08ced9434fe43', 'admin', '', ''),
(15, 'Contacto', 'contactoventas@automayoreo.com', 'AM2023**', 'fd9cebea4a3b0311815e878e3479c3e9', 'admin', '', ''),
(2, 'demo', 'contacto@automayoreo', 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'capturista', '', ''),
(13, 'Asociado', 'alangeovs@gmail.com', 'Alan3001++', '54c64434eef038876667713345999352', 'asociado', '', ''),
(14, 'Automayoreo', 'ti@automayoreo.com', 'AM2023++', 'e406a7da2b9e3fff9e576269c9c6fdf6', 'asociado', '', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `CLASE` (`CLASE`,`TAG`);

--
-- Indices de la tabla `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `combustible`
--
ALTER TABLE `combustible`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indices de la tabla `marcas_res`
--
ALTER TABLE `marcas_res`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de la tabla `color`
--
ALTER TABLE `color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `combustible`
--
ALTER TABLE `combustible`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `marcas`
--
ALTER TABLE `marcas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `marcas_res`
--
ALTER TABLE `marcas_res`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tipo`
--
ALTER TABLE `tipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
